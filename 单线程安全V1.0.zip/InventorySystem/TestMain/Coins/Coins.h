#pragma once
#include "GoldCoin.h"
#include "SilverCoin.h"