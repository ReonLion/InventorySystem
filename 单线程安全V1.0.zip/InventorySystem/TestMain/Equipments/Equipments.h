#pragma once
#include "GoldRing.h"
#include "SilverRing.h"
#include "CopperRing.h"