#include "CoinBase.h"

CoinBase::CoinBase()
{
	this->type = COIN;
	this->bConsumable = true;
}

CoinBase::~CoinBase()
{
}
