#include "EquipmentBase.h"

EquipmentBase::EquipmentBase()
{
	this->type = EQUIPMENT;
	this->bConsumable = false;
}

EquipmentBase::~EquipmentBase()
{
}
