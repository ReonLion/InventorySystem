#pragma once

#include "Item.h"

class WeaponBase : public Item
{
public:
	WeaponBase();
	~WeaponBase();
};
