#pragma once

#include "Item.h"

class CoinBase : public Item
{
public:
	CoinBase();
	~CoinBase();
};
