#pragma once

#include "Item.h"

class ClothBase : public Item
{
public:
	ClothBase();
	~ClothBase();
};
