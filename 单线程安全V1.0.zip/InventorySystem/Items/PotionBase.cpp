#include "PotionBase.h"

PotionBase::PotionBase()
{
	this->type = POTION;
	this->bConsumable = true;
}

PotionBase::~PotionBase()
{
}
