#pragma once

#include "Item.h"

class PotionBase : public Item
{
public:
	PotionBase();
	~PotionBase();
};
