#include "WeaponBase.h"

WeaponBase::WeaponBase()
{
	this->type = WEAPON;
	this->bConsumable = false;
}

WeaponBase::~WeaponBase()
{
}
