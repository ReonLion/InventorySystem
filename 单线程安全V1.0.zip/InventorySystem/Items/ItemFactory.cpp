#include "ItemFactory.h"

ItemFactory::ItemFactory()
{
}

ItemFactory::~ItemFactory()
{
}
