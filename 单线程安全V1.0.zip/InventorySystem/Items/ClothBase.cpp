#include "ClothBase.h"

ClothBase::ClothBase()
{
	this->type = CLOTH;
	this->bConsumable = false;
}

ClothBase::~ClothBase()
{
}
