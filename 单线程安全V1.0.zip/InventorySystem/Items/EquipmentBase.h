#pragma once

#include "Item.h"

class EquipmentBase : public Item
{
public:
	EquipmentBase();
	~EquipmentBase();
};
