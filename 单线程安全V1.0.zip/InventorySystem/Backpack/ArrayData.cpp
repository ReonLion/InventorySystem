#include "ArrayData.h"

ArrayData::ArrayData()
{
}

ArrayData::~ArrayData()
{
}
